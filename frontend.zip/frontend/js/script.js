document.getElementById("learn-more").addEventListener("click", () => {
    alert("Découvrez les événements et les activités de notre club universitaire !");
});